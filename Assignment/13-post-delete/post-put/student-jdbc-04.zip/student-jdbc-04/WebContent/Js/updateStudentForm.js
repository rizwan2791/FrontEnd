
	  const form = document.getElementById('myForm');

form.style.display = 'none';  

function update(student){
	  const form = document.getElementById('myForm');

    let fname = document.querySelector("#fname");
    let lname = document.querySelector("#lname");

    let email = document.querySelector("#email");

    
console.log(fname)
    fname.value = student[0].fname;
    
    lname.value = student[0].rollNo;
    

    email.value = student[0].email;


 

    if (form.style.display === 'none') {
      
       form.style.display = 'block';
    
    } else {
  
       form.style.display = 'none';
     
    }
}
  
  